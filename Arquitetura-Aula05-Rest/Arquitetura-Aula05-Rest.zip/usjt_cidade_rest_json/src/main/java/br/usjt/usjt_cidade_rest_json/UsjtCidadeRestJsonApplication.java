package br.usjt.usjt_cidade_rest_json;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsjtCidadeRestJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsjtCidadeRestJsonApplication.class, args);
	}

}
