package br.usjt.usjt_cidade_rest_json;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsjtCidadeRestJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
